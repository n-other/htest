/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef _CPU_SHA256_H
#define _CPU_SHA256_H

void sha256_64 (const u32 block[16], u32 digest[8]);

#endif // _CPU_SHA256_H

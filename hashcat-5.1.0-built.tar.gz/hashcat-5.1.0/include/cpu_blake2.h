/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef _CPU_BLAKE2_H
#define _CPU_BLAKE2_H

#endif // _CPU_BLAKE2_H
